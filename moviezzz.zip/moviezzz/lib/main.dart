import 'package:flutter/material.dart';
import 'package:moviezzz/src/app.dart';

void main() => runApp(App());

